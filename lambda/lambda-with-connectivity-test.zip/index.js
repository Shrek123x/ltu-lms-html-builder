/**
 * AWS Lambda Function - HTML Generator with EC2 Database Integration
 * Fetches messages from EC2 API endpoint and generates HTML
 * 
 * Features:
 * - Test EC2 connectivity
 * - Fetch messages from EC2 API
 * - Generate HTML reports
 * - Support manual JSON input
 */

exports.handler = async (event) => {
    console.log('Lambda invoked with event:', JSON.stringify(event));
    const startTime = Date.now();

    try {
        // Special Mode: Test EC2 Connectivity Only
        if (event.testConnection) {
            console.log('=== Testing EC2 Connectivity ===');
            return await testEC2Connection(event);
        }

        // Option 1: Use messages from event (manual invocation)
        let messages = event.messages || [];
        let theme = event.theme || 'light';

        // Option 2: Fetch from EC2 API if no messages provided
        if (messages.length === 0 && event.fetchFromEC2) {
            const ec2ApiUrl = event.ec2ApiUrl || process.env.EC2_API_URL || 'http://52.63.56.25:3000/api/messages';
            
            console.log('Fetching messages from EC2:', ec2ApiUrl);
            
            // Test connection first
            const connectionTest = await testEC2Connection({
                ec2ApiUrl: ec2ApiUrl,
                silent: true
            });
            
            if (!connectionTest.success) {
                console.error('EC2 connectivity test failed:', connectionTest.message);
                return {
                    statusCode: 503,
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ 
                        error: 'EC2 instance not reachable',
                        details: connectionTest.message,
                        troubleshooting: connectionTest.troubleshooting
                    })
                };
            }
            
            console.log('EC2 connectivity test passed:', connectionTest.message);
            
            try {
                const response = await fetch(ec2ApiUrl);
                if (!response.ok) {
                    throw new Error(`EC2 API returned ${response.status}`);
                }
                messages = await response.json();
                console.log(`Fetched ${messages.length} messages from EC2 (${connectionTest.responseTime}ms)`);
            } catch (fetchError) {
                console.error('Error fetching from EC2:', fetchError);
                return {
                    statusCode: 500,
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ 
                        error: 'Failed to fetch messages from EC2',
                        details: fetchError.message,
                        hint: 'EC2 instance may be down or API endpoint changed'
                    })
                };
            }
        }

        // Validate messages
        if (!messages || messages.length === 0) {
            return {
                statusCode: 400,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    error: 'No messages provided',
                    hint: 'Either provide messages in event.messages or set event.fetchFromEC2 = true'
                })
            };
        }

        // Generate HTML
        const html = generateHTML(messages, theme);

        return {
            statusCode: 200,
            headers: {
                'Content-Type': 'text/html',
                'Access-Control-Allow-Origin': '*'
            },
            body: html
        };

    } catch (error) {
        console.error('Error in Lambda handler:', error);
        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                error: 'Internal server error',
                details: error.message 
            })
        };
    }
};

/**
 * Test EC2 Connection
 * Tests if Lambda can reach the EC2 instance
 * 
 * @param {Object} event - Event object with ec2ApiUrl
 * @returns {Object} Connection test results
 */
async function testEC2Connection(event) {
    const ec2ApiUrl = event.ec2ApiUrl || process.env.EC2_API_URL || 'http://52.63.56.25:3000/api/messages';
    const silent = event.silent || false;
    
    const result = {
        success: false,
        message: '',
        ec2Url: ec2ApiUrl,
        timestamp: new Date().toISOString(),
        tests: {}
    };
    
    if (!silent) {
        console.log('Testing EC2 connectivity to:', ec2ApiUrl);
    }
    
    try {
        // Test 1: Basic HTTP connectivity
        const startTime = Date.now();
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 5000); // 5 second timeout
        
        try {
            const response = await fetch(ec2ApiUrl, {
                signal: controller.signal,
                headers: {
                    'User-Agent': 'AWS-Lambda-Test'
                }
            });
            clearTimeout(timeoutId);
            
            const responseTime = Date.now() - startTime;
            result.responseTime = `${responseTime}ms`;
            
            result.tests.httpConnection = {
                passed: true,
                status: response.status,
                statusText: response.statusText,
                responseTime: responseTime
            };
            
            // Test 2: Valid JSON response
            if (response.ok) {
                try {
                    const data = await response.json();
                    result.tests.jsonResponse = {
                        passed: true,
                        messageCount: Array.isArray(data) ? data.length : 0,
                        dataType: Array.isArray(data) ? 'array' : typeof data
                    };
                    
                    // Test 3: Data structure validation
                    if (Array.isArray(data) && data.length > 0) {
                        const firstMessage = data[0];
                        const hasRequiredFields = 
                            firstMessage.hasOwnProperty('id') &&
                            firstMessage.hasOwnProperty('text') &&
                            firstMessage.hasOwnProperty('level');
                        
                        result.tests.dataStructure = {
                            passed: hasRequiredFields,
                            sampleMessage: hasRequiredFields ? {
                                id: firstMessage.id,
                                text: firstMessage.text.substring(0, 50) + '...',
                                level: firstMessage.level
                            } : null
                        };
                        
                        if (hasRequiredFields) {
                            result.success = true;
                            result.message = `EC2 is reachable and API is working correctly (${data.length} messages)`;
                        } else {
                            result.message = 'EC2 is reachable but data structure is invalid';
                        }
                    } else if (Array.isArray(data)) {
                        result.success = true;
                        result.message = 'EC2 is reachable but database is empty';
                        result.tests.dataStructure = {
                            passed: true,
                            note: 'Empty database - no messages to validate'
                        };
                    } else {
                        result.message = 'EC2 responded but data is not an array';
                    }
                    
                } catch (jsonError) {
                    result.tests.jsonResponse = {
                        passed: false,
                        error: 'Response is not valid JSON'
                    };
                    result.message = 'EC2 is reachable but response is not valid JSON';
                }
            } else {
                result.message = `EC2 responded with error status: ${response.status}`;
            }
            
        } catch (fetchError) {
            clearTimeout(timeoutId);
            
            if (fetchError.name === 'AbortError') {
                result.tests.httpConnection = {
                    passed: false,
                    error: 'Request timeout (>5 seconds)'
                };
                result.message = 'EC2 connection timeout - instance may be overloaded or down';
                result.troubleshooting = [
                    'Check if EC2 instance is running (AWS Console)',
                    'Verify Docker container is running: docker ps',
                    'Check EC2 logs: docker logs ltu-app',
                    'Test locally on EC2: curl http://localhost:3000/api/messages',
                    'Increase Lambda timeout to 30 seconds'
                ];
            } else if (fetchError.message.includes('ECONNREFUSED')) {
                result.tests.httpConnection = {
                    passed: false,
                    error: 'Connection refused'
                };
                result.message = 'EC2 refused connection - Docker container may not be running';
                result.troubleshooting = [
                    'SSH to EC2 and run: docker ps',
                    'Start container if stopped: docker start ltu-app',
                    'Check security group allows port 3000',
                    'Verify app is listening on 0.0.0.0:3000'
                ];
            } else if (fetchError.message.includes('ENOTFOUND') || fetchError.message.includes('getaddrinfo')) {
                result.tests.httpConnection = {
                    passed: false,
                    error: 'Host not found'
                };
                result.message = 'Cannot resolve EC2 hostname - check IP address';
                result.troubleshooting = [
                    'Verify EC2 public IP is correct',
                    'Check if EC2 instance is running',
                    'Ensure EC2 has a public IP assigned'
                ];
            } else {
                result.tests.httpConnection = {
                    passed: false,
                    error: fetchError.message
                };
                result.message = `Connection failed: ${fetchError.message}`;
                result.troubleshooting = [
                    'Check EC2 security group allows inbound on port 3000 from 0.0.0.0/0',
                    'Verify EC2 instance is running',
                    'Check Docker container: docker ps',
                    'Test API locally: curl http://localhost:3000/api/messages'
                ];
            }
        }
        
    } catch (error) {
        result.message = `Unexpected error: ${error.message}`;
        result.troubleshooting = [
            'Check Lambda CloudWatch logs for details',
            'Verify Lambda has internet access',
            'Increase Lambda timeout if needed'
        ];
    }
    
    // Return detailed results if not in silent mode
    if (!silent) {
        console.log('EC2 Connection Test Results:', JSON.stringify(result, null, 2));
        
        return {
            statusCode: result.success ? 200 : 503,
            headers: { 
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            body: JSON.stringify(result, null, 2)
        };
    }
    
    return result;
}

/**
 * Generate HTML from messages
 */
function generateHTML(messages, theme = 'light') {
    // Calculate statistics
    const stats = {
        total: messages.length,
        info: messages.filter(m => m.level === 'info').length,
        warning: messages.filter(m => m.level === 'warning').length,
        error: messages.filter(m => m.level === 'error').length,
        success: messages.filter(m => m.level === 'success').length,
        resolved: messages.filter(m => m.resolved).length,
        unresolved: messages.filter(m => !m.resolved).length
    };

    // Group by sender
    const bySender = {};
    messages.forEach(m => {
        bySender[m.from] = (bySender[m.from] || 0) + 1;
    });

    // Colors based on theme
    const isDark = theme === 'dark';
    const colors = {
        bg: isDark ? '#1a1a1a' : '#ffffff',
        text: isDark ? '#ffffff' : '#000000',
        card: isDark ? '#2d2d2d' : '#f5f5f5',
        border: isDark ? '#404040' : '#e0e0e0',
        info: '#3b82f6',
        warning: '#f59e0b',
        error: '#ef4444',
        success: '#10b981'
    };

    // Generate message cards HTML
    const messageCards = messages.map(msg => {
        const levelColor = colors[msg.level] || colors.info;
        const date = new Date(msg.timestamp);
        
        return `
        <div class="message-card" data-level="${msg.level}">
            <div class="message-header">
                <span class="message-level" style="background-color: ${levelColor}">
                    ${msg.level.toUpperCase()}
                </span>
                <span class="message-from">${escapeHtml(msg.from)}</span>
                ${msg.resolved ? '<span class="message-resolved">✓ Resolved</span>' : ''}
            </div>
            <div class="message-text">${escapeHtml(msg.text)}</div>
            <div class="message-footer">
                <span class="message-id">ID: ${msg.id}</span>
                <span class="message-time">${date.toLocaleString()}</span>
            </div>
        </div>`;
    }).join('');

    // Generate sender stats HTML
    const senderStats = Object.entries(bySender)
        .map(([sender, count]) => `<li>${escapeHtml(sender)}: ${count} messages</li>`)
        .join('');

    // Complete HTML document
    return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CourtRoom Messages Report</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            background-color: ${colors.bg};
            color: ${colors.text};
            padding: 20px;
            line-height: 1.6;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .header {
            text-align: center;
            margin-bottom: 40px;
            padding: 30px;
            background-color: ${colors.card};
            border-radius: 10px;
            border: 2px solid ${colors.border};
        }
        
        .header h1 {
            font-size: 2.5rem;
            margin-bottom: 10px;
        }
        
        .header p {
            color: ${isDark ? '#aaa' : '#666'};
            font-size: 0.9rem;
        }
        
        .stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background-color: ${colors.card};
            padding: 20px;
            border-radius: 8px;
            border: 2px solid ${colors.border};
            text-align: center;
        }
        
        .stat-number {
            font-size: 2rem;
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .stat-label {
            color: ${isDark ? '#aaa' : '#666'};
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .stat-info { color: ${colors.info}; }
        .stat-warning { color: ${colors.warning}; }
        .stat-error { color: ${colors.error}; }
        .stat-success { color: ${colors.success}; }
        
        .filters {
            margin-bottom: 20px;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            justify-content: center;
        }
        
        .filter-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.9rem;
            transition: transform 0.2s;
        }
        
        .filter-btn:hover {
            transform: scale(1.05);
        }
        
        .filter-btn.active {
            box-shadow: 0 0 0 3px ${colors.border};
        }
        
        .messages {
            display: grid;
            gap: 15px;
        }
        
        .message-card {
            background-color: ${colors.card};
            border-left: 4px solid ${colors.info};
            padding: 20px;
            border-radius: 8px;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        
        .message-card:hover {
            transform: translateX(5px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }
        
        .message-card[data-level="info"] { border-left-color: ${colors.info}; }
        .message-card[data-level="warning"] { border-left-color: ${colors.warning}; }
        .message-card[data-level="error"] { border-left-color: ${colors.error}; }
        .message-card[data-level="success"] { border-left-color: ${colors.success}; }
        
        .message-header {
            display: flex;
            gap: 10px;
            align-items: center;
            margin-bottom: 10px;
            flex-wrap: wrap;
        }
        
        .message-level {
            padding: 4px 12px;
            border-radius: 4px;
            font-size: 0.75rem;
            font-weight: bold;
            color: white;
        }
        
        .message-from {
            font-weight: 600;
            color: ${isDark ? '#aaa' : '#555'};
        }
        
        .message-resolved {
            margin-left: auto;
            padding: 4px 12px;
            background-color: ${colors.success};
            color: white;
            border-radius: 4px;
            font-size: 0.75rem;
        }
        
        .message-text {
            font-size: 1.1rem;
            margin-bottom: 10px;
        }
        
        .message-footer {
            display: flex;
            justify-content: space-between;
            color: ${isDark ? '#777' : '#999'};
            font-size: 0.85rem;
        }
        
        .sender-stats {
            margin-top: 30px;
            padding: 20px;
            background-color: ${colors.card};
            border-radius: 8px;
            border: 2px solid ${colors.border};
        }
        
        .sender-stats h3 {
            margin-bottom: 15px;
        }
        
        .sender-stats ul {
            list-style-position: inside;
        }
        
        .sender-stats li {
            padding: 5px 0;
        }
        
        .footer {
            margin-top: 40px;
            text-align: center;
            color: ${isDark ? '#777' : '#999'};
            font-size: 0.85rem;
            padding: 20px;
            border-top: 2px solid ${colors.border};
        }
        
        .no-messages {
            text-align: center;
            padding: 60px 20px;
            color: ${isDark ? '#777' : '#999'};
            font-size: 1.2rem;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Welcome to CourtRoom Simulator</h1>
            <p>Generated: ${new Date().toLocaleString()}</p>
        </div>
        
        <div class="stats">
            <div class="stat-card">
                <div class="stat-number">${stats.total}</div>
                <div class="stat-label">Total Messages</div>
            </div>
            <div class="stat-card">
                <div class="stat-number stat-info">${stats.info}</div>
                <div class="stat-label">Info</div>
            </div>
            <div class="stat-card">
                <div class="stat-number stat-warning">${stats.warning}</div>
                <div class="stat-label">Warnings</div>
            </div>
            <div class="stat-card">
                <div class="stat-number stat-error">${stats.error}</div>
                <div class="stat-label">Urgent</div>
            </div>
            <div class="stat-card">
                <div class="stat-number stat-success">${stats.success}</div>
                <div class="stat-label">Success</div>
            </div>
        </div>
        
        <div class="filters">
            <button class="filter-btn active" onclick="filterMessages('all')" style="background-color: ${colors.border}; color: ${colors.text};">
                All (${stats.total})
            </button>
            <button class="filter-btn" onclick="filterMessages('info')" style="background-color: ${colors.info}; color: white;">
                Info (${stats.info})
            </button>
            <button class="filter-btn" onclick="filterMessages('warning')" style="background-color: ${colors.warning}; color: white;">
                Warnings (${stats.warning})
            </button>
            <button class="filter-btn" onclick="filterMessages('error')" style="background-color: ${colors.error}; color: white;">
                Urgent (${stats.error})
            </button>
            <button class="filter-btn" onclick="filterMessages('success')" style="background-color: ${colors.success}; color: white;">
                Success (${stats.success})
            </button>
        </div>
        
        <div class="messages" id="messages">
            ${messages.length > 0 ? messageCards : '<div class="no-messages">No messages to display</div>'}
        </div>
        
        ${messages.length > 0 ? `
        <div class="sender-stats">
            <h3>Messages by Sender</h3>
            <ul>${senderStats}</ul>
        </div>
        ` : ''}
        
        <div class="footer">
            <p><strong>Generated by AWS Lambda</strong> | LTU LMS HTML Builder</p>
            <p>Theme: ${theme} | Total Messages: ${stats.total}</p>
        </div>
    </div>
    
    <script>
        function filterMessages(level) {
            const cards = document.querySelectorAll('.message-card');
            const buttons = document.querySelectorAll('.filter-btn');
            
            buttons.forEach(btn => btn.classList.remove('active'));
            event.target.classList.add('active');
            
            cards.forEach(card => {
                if (level === 'all' || card.dataset.level === level) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        }
    </script>
</body>
</html>`;
}

/**
 * Escape HTML to prevent XSS attacks
 */
function escapeHtml(unsafe) {
    if (typeof unsafe !== 'string') return '';
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}
